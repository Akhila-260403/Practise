import { Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Login } from './components/login/login';
import { Register } from './components/register/register';
import { Plans } from './components/plans/plans';
import { About } from './components/about/about';
// import { PlanDetails } from './components/plan-details/plan-details';
import { Buy } from './components/buy/buy';
export const routes: Routes = [
    {
        path:'',
        component:Home
    },
    {
        path:'login',
        component:Login
    },
    {
        path:'register',
        component:Register
    },
    {
        path:'plans',
        component:Plans
    },
    {
        path:'about',
        component:About
    },
    // {
    //     path:'plans/:type',
    //     component:PlanDetails
    // }
    {
        path:'buy',
        component:Buy
    }
];
