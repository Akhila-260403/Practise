import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from "@angular/router";
import { Router } from '@angular/router';
import {CommonModule} from '@angular/common';

import {NavigationEnd} from '@angular/router';
@Component({
  selector: 'app-plans',
  standalone:true,
  imports: [RouterLink,CommonModule],
  templateUrl: './plans.html',
  styleUrl: './plans.css',
})
export class Plans implements OnInit {
  selectedPlan : any = null;
  plans : any[] = [];

  constructor(private http:HttpClient,private router:Router){}

  ngOnInit(): void {
  this.loadPlans();

  this.router.events.subscribe(event=> {
    if(event instanceof NavigationEnd && event.url === '/plans'){
      this.loadPlans();
    }
  })
  }

  openPlan(plan:any){
    this.selectedPlan=plan;
  }
  closePlan(){
    this.selectedPlan=null;
  }
  loadPlans(){
    this.http.get<any[]>('assets/data/plans.json')
    .subscribe((data: any[]) => {
     console.log('PLANS DATA:', data)
       this.plans=data;
    });
  }
  buyPlan(){
    this.router.navigate(['/buy'] , {
      state : {plan : this.selectedPlan}
    });
  }

}