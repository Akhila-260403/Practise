import { Component } from '@angular/core';

@Component({
  selector: 'app-confirmation',
  imports: [],
  templateUrl: './confirmation.html',
  styleUrl: './confirmation.css',
})
export class Confirmation {
data:any;
today=new Date();
constructor(){
  this.data = history.state;
}
}
