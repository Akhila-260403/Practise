import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-buy',
  standalone: true,         // if Angular 15+
  imports: [CommonModule, FormsModule],
  templateUrl: './buy.html',
  styleUrls: ['./buy.css'],  // corrected from styleUrl
})
export class Buy {
  plan: any = null;
  paymentMode: string = '';
  frequency: string = '';

  constructor(private router: Router) {
    this.plan = history.state?.plan || null;
  }

  confirmPurchase() {
    if (!this.paymentMode || !this.frequency) {
      alert('Please select Payment Mode and Frequency.');
      return;
    }

    console.log('confirm clicked', this.plan, this.paymentMode, this.frequency);

    this.router.navigate(['/confirmation'], {
      state: {
        plan: this.plan,
        paymentMode: this.paymentMode,
        frequency: this.frequency,
      },
    });
  }
}
